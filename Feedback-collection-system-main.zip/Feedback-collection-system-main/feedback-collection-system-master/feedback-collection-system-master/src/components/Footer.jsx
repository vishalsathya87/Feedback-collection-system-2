

const Footer = () => {
  return (
    <div className="bg-body-tertiary w-full bottom-0 p-4 fixed text-center">
      &copy; Zidio development Intern Feedback collection system
    </div>
  )
}

export default Footer
