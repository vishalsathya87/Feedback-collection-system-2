const NotFound = () => {
  return (
    <div className="m-auto">
      <h3 className="text-yellow-300">Oops! This page is not found</h3>
    </div>
  );
};

export default NotFound;
