// import AdminDashboard from "@/components/AdminDashboard"
import AdminDashboard from "@/components/AdminDashboard"
import Navbarpanel from "@/components/Navbarpanel"
import { Settings } from "@/components/Settings"
import Sidebar from "@/components/Sidebar"



const DashboardLayout = () => {
  return (
   <main>
  
    {/* <AdminDashboard/> */}
    {/* may not be applicable please take the fucking note */}
   </main>
  )
}

export default DashboardLayout
