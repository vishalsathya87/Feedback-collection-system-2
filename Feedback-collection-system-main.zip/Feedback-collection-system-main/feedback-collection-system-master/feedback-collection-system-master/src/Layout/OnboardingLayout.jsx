import LandingPage from "@/pages/LandingPage"


const OnboardingLayout = () => {
  return (
    <div>
      <LandingPage/>
    </div>
  )
}

export default OnboardingLayout
