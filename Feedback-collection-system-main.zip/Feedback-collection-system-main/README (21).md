Feedback collection system

Building a feedback collection system that collects the users feedback. The software requirement specification (srs) of this project is simple; authenticate users, multi-channel accessibility, and notification system for timely updates. Administrators benefits from analytical tools, feedback tracking and integration capabilities.

project link

project work layout
<img width="756" height="428" alt="feedback01" src="https://github.com/user-attachments/assets/66ca6175-8d69-458c-af3c-83ba56ff667c" />

<img width="507" height="432" alt="feedback02" src="https://github.com/user-attachments/assets/26f409dc-0364-42a0-83db-3ec30568f53a" />

<img width="945" height="396" alt="feedback03" src="https://github.com/user-attachments/assets/0f92ce2f-dd6c-4b95-ac1c-c3f19b5ba81e" />
